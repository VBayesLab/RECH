function residual = LSTM_tGARCH_residual_analysis(y,Post_RECH)

beta0 = mean(Post_RECH.LikAnneal.beta0);
beta1 = mean(Post_RECH.LikAnneal.beta1);
psi1 = mean(Post_RECH.LikAnneal.psi1);
psi2 = mean(Post_RECH.LikAnneal.psi2);
nu = mean(Post_RECH.LikAnneal.nu);
v_f = mean(Post_RECH.LikAnneal.v_f);
w_f = mean(Post_RECH.LikAnneal.w_f);
b_f = mean(Post_RECH.LikAnneal.b_f);
v_i = mean(Post_RECH.LikAnneal.v_i);
w_i = mean(Post_RECH.LikAnneal.w_i);
b_i = mean(Post_RECH.LikAnneal.b_i);
v_o = mean(Post_RECH.LikAnneal.v_o);
w_o = mean(Post_RECH.LikAnneal.w_o);
b_o = mean(Post_RECH.LikAnneal.b_o);
v_d = mean(Post_RECH.LikAnneal.v_d);
w_d = mean(Post_RECH.LikAnneal.w_d);
b_d = mean(Post_RECH.LikAnneal.b_d);

T      = length(y);
h      = zeros(T,1);
omega    = zeros(T,1);
sigma2 = zeros(T,1);
sigma20 = var(y);

% Initialization
t = 1;
h(t) = 0;
omega(t) = beta0 + beta1*h(t);
sigma2(t) = sigma20;
C(t) = 0;
for t = 2:T
    input = [omega(t-1),y(t-1),sigma2(t-1)]'; % input to LSTM
    g_f      = activation(v_f*input + w_f*h(t-1) + b_f,'Tanh');
    g_i      = activation(v_i*input + w_i*h(t-1) + b_i,'Tanh');
    g_o      = activation(v_o*input + w_o*h(t-1) + b_o,'Sigmoid');
    g_d      = activation(v_d*input + w_d*h(t-1) + b_d,'Tanh');
    C(t)     = g_f.*C(t-1)+g_i.*g_d;    
    h(t)     = g_o.*activation(C(t),'Sigmoid');
    omega(t) = beta0 + beta1*h(t);    
    sigma2(t) = omega(t) + psi1*(1-psi2)*y(t-1)^2 + psi1*psi2*sigma2(t-1);
end

t_residuals = y./sqrt(sigma2);
uniform_residuals = tcdf(t_residuals,nu);
std_residuals = norminv(uniform_residuals);
% figure
% subplot(1,3,1)
% plot(std_residuals)
% title('RECH: Standardized residuals')
% subplot(1,3,2)
% [f,x] = ksdensity(std_residuals);   
% plot(x,f,'-','LineWidth',2)
% title('RECH: Standardized residuals')
% subplot(1,3,3)
% qqplot(std_residuals)
% title('RECH: Standardized residuals QQ-plot')

residual.std_residuals = std_residuals;
residual.t_residuals = t_residuals;

end









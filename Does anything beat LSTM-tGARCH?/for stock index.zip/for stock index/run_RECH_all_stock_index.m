clear all
clc
% ==============================================%
% run all indexes
stock_name_list    = {'AEX','AORD','BFX','BSESN','BVLG','BVSP','DJI','FCHI','FTMIB','FTSE',...
    'GDAXI','GSPTSE','HSI','IBEX','IXIC','KS11','KSE','MXX','N225','NSEI','OMXC20','OMXHPI','OMXSPI',...
    'OSEAX','RUT','SMSI','SPX','SSEC','SSMI','STI','STOXX50E'};

for j = 1:length(stock_name_list)
    stock_name = stock_name_list{j};       
    disp('=========== stock name =====================')
    stock_name
    disp('==============================================')
    
    %% prepare data
    data       = load('realized_data.mat');
    price      = data.(stock_name).close_price; 
    y_all      = log(price(2:end)./price(1:end-1)); % the first day isn't included
    y_all      =  100*(y_all-mean(y_all)); % returns (from the 2nd day)
    rv_all     = 10^4*data.(stock_name).rv5(2:end); % realized volatility; rv_all(t) realizes the volatility of y_all(t)
    if length(y_all) > 3000
        y_all      = y_all(end-2999:end); % use the last 3000 days        
        rv_all     = rv_all(end-2999:end); 
        T          = 2000; % training size
    else
        T = round(length(y_all)*2/3);
    end        
    y          = y_all(1:T); 
    rv          = rv_all(1:T); 
    rv_all     = sum(y.^2)/sum(rv)*rv_all; % rescale (using training data) to reflect overnight variation    
    mdl.rv_all = rv_all;
    clear data

    % Training setting
    mdl.T_anneal = 10000;    % Number of pre-specified annealing steps
    mdl.M        = 5000;     % Number of particles in each annealing stage
    mdl.K1_lik   = 50;       % Number of Markov moves 
    mdl.K2_lik   = 50;       % Number of Markov moves 
    mdl.T        = T;        % size of the training time series 
    y            = y_all(1:mdl.T);  % training data
    mdl.sigma20  = var(y); %  initialize volatility in the GARCH formula with sample variance of the returns
    mdl.MV_scale = 1.5;

    % Prior setting: Gamma is used for the prior of beta_0 and beta_1, 
    % uniform(0,1) prior is used for psi1, Beta for psi2, and normal prior for RNN
    % parameters
    mdl.prior.beta0_a0 = 1;     mdl.prior.beta0_b0  = 10;     % Gamma
    mdl.prior.beta1_a0 = 1;     mdl.prior.beta1_b0  = 10;    % Gamma
    mdl.prior.psi2_a0  = 10;    mdl.prior.psi2_b0 = 2;
    mdl.prior.nu_a0    = 1;     mdl.prior.nu_b0 = 1;
    mdl.prior.v_mu = 0;         mdl.prior.v_var = .2;    % Normal distribution
    mdl.prior.w_mu = 0;         mdl.prior.w_var = .2;    % Normal distribution
    mdl.prior.b_mu = 0;         mdl.prior.b_var = .2;    % Normal distribution 

    % Run Likelihood annealing for in-sample data
    Post_RECH.mdl = mdl;
    Post_RECH.LikAnneal = LSTM_tGARCH_LikAnneal(y,mdl);

    % Forecast with data annealing
    mdl.lik_anneal          = Post_RECH.LikAnneal;
    mdl.MV_scale            = 1;
    mdl.K_data              = 30    ;

    Post_RECH.DataAnneal = LSTM_tGARCH_DataAnneal(y_all,mdl);

    volatility_proxy    = mdl.rv_all(mdl.T+1:end);
    volatility_est      = Post_RECH.DataAnneal.volatility_forecast;
    Post_RECH.DataAnneal.predictive_score = predictive_score(volatility_proxy,volatility_est);
    Post_RECH.LikAnneal.residual = LSTM_tGARCH_residual_analysis(y,Post_RECH);

    str = 'Results_RECH_SMC_';
    str = append(str,stock_name);    
    save(str)

end

















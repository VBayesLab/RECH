function [llh,sigma2_end,omega_end,h_end,cell_end] = LSTM_tGARCH_llh(y,sigma20,theta_particles,input_size)
% Calculate log-likelihood of LSTM-tGARCH 
% INPUT
% y             : data
% x             : covariate time series
% sigma20       : initial volatility
% returns data y, covariates x and model parameters
% OUTPUT
% llh           : log-likelihood
% sigma2_end    : conditional sigma2(T) calculated at the last time T. Needed for subsequent calculation
% omega_end     : RNN component omega(T) calculated at the last time T. Needed for subsequent calculation
% h_end         : hidden layer h(T) calculated at the last time T. Needed for subsequent calculation

beta0   = theta_particles(:,1);
beta1   = theta_particles(:,2);
psi1    = theta_particles(:,3);
psi2    = theta_particles(:,4);
nu      = theta_particles(:,5);
w_f       = theta_particles(:,6);
b_f       = theta_particles(:,7);
v_f       = theta_particles(:,8:7+input_size);
w_i       = theta_particles(:,8+input_size);
b_i       = theta_particles(:,9+input_size);
v_i       = theta_particles(:,10+input_size:9+2*input_size);
w_o       = theta_particles(:,10+2*input_size);
b_o       = theta_particles(:,11+2*input_size);
v_o       = theta_particles(:,12+2*input_size:11+3*input_size);
w_d       = theta_particles(:,12+3*input_size);
b_d       = theta_particles(:,13+3*input_size);
v_d       = theta_particles(:,14+3*input_size:end);

T      = length(y);
h      = zeros(T,1);
omega  = zeros(T,1);
sigma2 = zeros(T,1);

% Initialization
t = 1;
h(t) = 0;
omega(t) = beta0 + beta1*h(t);
sigma2(t) = sigma20;
C(t) = 0;
for t = 2:T
    input = [omega(t-1),y(t-1),sigma2(t-1)]'; % input to LSTM
    g_f      = activation(v_f*input + w_f*h(t-1) + b_f,'Tanh');
    g_i      = activation(v_i*input + w_i*h(t-1) + b_i,'Tanh');
    g_o      = activation(v_o*input + w_o*h(t-1) + b_o,'Sigmoid');
    g_d      = activation(v_d*input + w_d*h(t-1) + b_d,'Tanh');
    C(t)     = g_f.*C(t-1)+g_i.*g_d;    
    h(t)     = g_o.*activation(C(t),'Sigmoid');
    omega(t) = beta0 + beta1*h(t);    
    sigma2(t) = omega(t) + psi1*(1-psi2)*y(t-1)^2 + psi1*psi2*sigma2(t-1);
end

llh = sum(log(pdf('tLocationScale',y,0,sqrt(sigma2),nu)));

sigma2_end = sigma2(end);
omega_end = omega(end);
h_end = h(end);
cell_end = C(end);

end

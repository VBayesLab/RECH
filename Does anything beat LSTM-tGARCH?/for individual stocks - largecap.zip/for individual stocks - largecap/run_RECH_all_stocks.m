clear all
clc
% ==============================================%
stock_name_list    = {'CBA','ANZ','WBC','WES','BHP','TLS','RIO','MQG','NAB','FMG',...
    'AAPL','MSFT','AMZN','NVDA','GOOG','META','TSLA','XOM','JNJ','UNH',...
    'AON','BTI','BP','SHEL','GSK','DEO','UL','LIN','AZN','HSBA',...
    'MUFG','T6861','TM','T8058','T4063','T9433','T4661','T7203','T6758','T9984',...
        'MBGDE','SAPDE','ALVDE','SIEDE','DPWDE','BAYNDE','BMWDE','VOWDE','MUV2DE','IFXDE'};
    
for i = 1:length(stock_name_list)
    stock_name = stock_name_list{i};       
    disp('=========== stock name =====================')
    stock_name
    disp('==============================================')
    
    %% prepare data
    load('individual_stock_data.mat');
    price      = data.(stock_name).close_price; price = price(~isnan(price));
    y_all      = 100*log(price(2:end)./price(1:end-1)); % the first day isn't included    
    T = 2000;
    y = y_all(1:T); y_test = y_all(T+1:end);
    y_test = (y_test-mean(y))/std(y);
    y = (y-mean(y))/std(y);
    y_all = [y;y_test];   
    rv_all     = 10^2*y_all.^2; % not reall rv; just for coding purposes
    mdl.rv_all = rv_all;
    clear data

    % Training setting
    mdl.T_anneal = 10000;    % Number of pre-specified annealing steps
    mdl.M        = 5000;     % Number of particles in each annealing stage
    mdl.K1_lik   = 50;       % Number of Markov moves 
    mdl.K2_lik   = 50;       % Number of Markov moves 
    mdl.T        = T;        % size of the training time series 
    y            = y_all(1:mdl.T);  % training data
    mdl.sigma20  = var(y); %  initialize volatility in the GARCH formula with sample variance of the returns
    mdl.MV_scale = 1.5;

    % Prior setting: Gamma is used for the prior of beta_0 and beta_1, 
    % uniform(0,1) prior is used for psi1, Beta for psi2, and normal prior for RNN
    % parameters
    mdl.prior.beta0_a0 = 1;     mdl.prior.beta0_b0  = 10;     % Gamma
    mdl.prior.beta1_a0 = 1;     mdl.prior.beta1_b0  = 10;    % Gamma
    mdl.prior.psi2_a0  = 10;    mdl.prior.psi2_b0 = 2;
    mdl.prior.nu_a0    = 1;     mdl.prior.nu_b0 = 1;
    mdl.prior.v_mu = 0;         mdl.prior.v_var = .2;    % Normal distribution
    mdl.prior.w_mu = 0;         mdl.prior.w_var = .2;    % Normal distribution
    mdl.prior.b_mu = 0;         mdl.prior.b_var = .2;    % Normal distribution 

    % Run Likelihood annealing for in-sample data
    Post_RECH.mdl = mdl;
    Post_RECH.LikAnneal = LSTM_tGARCH_LikAnneal(y,mdl);

    % Forecast with data annealing
    mdl.lik_anneal          = Post_RECH.LikAnneal;
    mdl.MV_scale            = 1;
    mdl.K_data              = 50;

    Post_RECH.DataAnneal = LSTM_tGARCH_DataAnneal(y_all,mdl);

    volatility_proxy    = mdl.rv_all(mdl.T+1:end);
    volatility_est      = Post_RECH.DataAnneal.volatility_forecast;
    Post_RECH.DataAnneal.predictive_score = predictive_score(volatility_proxy,volatility_est);
    Post_RECH.LikAnneal.residual = LSTM_tGARCH_residual_analysis(y,Post_RECH);

    str = 'Results_RECH_SMC_';
    str = append(str,stock_name);    
    save(str)

end

















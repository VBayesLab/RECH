clear all
clc
% ==============================================%
stock_name_list = {'AGL','ALL','AMC','APA','BSL','FMG','GMG','QBE','WOW','NCM',... % AU mid-cap
    'SWN','CELH','SMCI','PARA','LECO','EMN','OC','RGA','AAL','REG',...% US mid-cap
    'DRX','HGT','HFG','HMSO','CBG','ASC','MSLH','TSCO','VOD','BARC',...% UK mid-cap
    'PAH3DE','SRT3DE','HNR1DE','IFXDE','BEIDE','ADSDE','EOANDE','HEN3DE','RWEDE','HEIDE',...% Ger mid-cap
    'T8015','T8267','T4307','T2802','T7201','T6502','T8421','T7270','T2503','T6701'}; % Japan mid-cap


for j = 1:length(stock_name_list)
    stock_name = stock_name_list{j};       
    disp('=========== stock name =====================')
    stock_name
    disp('==============================================')
    
    %% prepare data
    load('individual_stock_data.mat');
    price      = data.(stock_name).close_price; price = price(~isnan(price));
    y_all      = 100*log(price(2:end)./price(1:end-1)); % the first day isn't included    
    T = 2000;
    y = y_all(1:T); y_test = y_all(T+1:end);
    y_test = (y_test-mean(y))/std(y);
    y = (y-mean(y))/std(y);
    y_all = [y;y_test];   
    rv_all     = 10^2*y_all.^2; % not reall rv; just for coding purposes
    mdl.rv_all = rv_all;
    clear data

    % Training setting
    mdl.T_anneal = 10000;    % Number of pre-specified annealing steps
    mdl.M        = 5000;     % Number of particles in each annealing stage
    mdl.K_lik    = 50;       % Number of Markov moves 
    mdl.T        = T;     % size of the training time series 
    y            = y_all(1:mdl.T);  % training data
    mdl.sigma20  = var(y); %  initialize volatility in the tGARCH formula with sample variance of the returns

    % Prior setting: Gamma is used for the prior of w - the constant in the tGARCH formula, 
    % uniform(0,1) prior is used for psi1, and Beta(10,2) is used for psi2 to encourage persistence. 
    % Also, Gamma is used for the student's df
    mdl.prior.w_a0 = 1; mdl.prior.w_b0 = 1;       
    mdl.prior.psi2_a0 = 10; mdl.prior.psi2_b0 = 2;
    mdl.prior.nu_a0 = 1; mdl.prior.nu_b0 = 1;

    % Run Likelihood annealing for in-sample data
    Post_tGARCH.LikAnneal = tGARCH_LikAnneal(y,mdl);

    % Forecast with data annealing
    mdl.lik_anneal          = Post_tGARCH.LikAnneal;
    mdl.K_data              = 50;
    Post_tGARCH.DataAnneal = tGARCH_DataAnneal(y_all,mdl);

    volatility_proxy    = mdl.rv_all(mdl.T+1:end);
    volatility_est      = Post_tGARCH.DataAnneal.volatility_forecast;
    Post_tGARCH.DataAnneal.predictive_score = predictive_score(volatility_proxy,volatility_est);
    Post_tGARCH.LikAnneal.residual = tGARCH_residual_analysis(y,Post_tGARCH);

    str = 'Results_tGARCH_SMC_';
    str = append(str,stock_name);    
    save(str)

end

















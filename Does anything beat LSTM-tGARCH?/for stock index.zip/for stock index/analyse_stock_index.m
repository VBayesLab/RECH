clear all
clc

% ==============================================%
% analyze and compare performance across stocks
stock_list    = {'AEX','AORD','BFX','BSESN','BVLG','BVSP','DJI','FCHI','FTMIB','FTSE',...
    'GDAXI','GSPTSE','HSI','IBEX','IXIC','KS11','KSE','MXX','N225','NSEI','OMXC20','OMXHPI','OMXSPI',...
    'OSEAX','RUT','SMSI','SPX','SSEC','SSMI','STI','STOXX50E'};

llh = zeros(length(stock_list),2);
PPS = zeros(length(stock_list),2);
Qscore = zeros(length(stock_list),2);
MSE = zeros(length(stock_list),2);
MAE = zeros(length(stock_list),2);
Violate = zeros(length(stock_list),2);

for i = 1:length(stock_list)
    stock_name = stock_list{i};

    tGARCH_str = 'Results_tGARCH_SMC_';
    tGARCH_str = append(tGARCH_str,stock_name);
    load(tGARCH_str)
    llh(i,1) = Post_tGARCH.LikAnneal.log_llh;
    PPS(i,1) = Post_tGARCH.DataAnneal.score.PPS;
    Qscore(i,1) = Post_tGARCH.DataAnneal.score.Quantile_Score;      
    MSE(i,1) = Post_tGARCH.DataAnneal.predictive_score.MSE;
    MAE(i,1) = Post_tGARCH.DataAnneal.predictive_score.MAE;
    Violate(i,1) = Post_tGARCH.DataAnneal.score.Violate;
        
    RECH_str = 'Results_RECH_SMC_';
    RECH_str = append(RECH_str,stock_name);
    load(RECH_str)
    llh(i,2) = Post_RECH.LikAnneal.log_llh;
    PPS(i,2) = Post_RECH.DataAnneal.score.PPS;
    Qscore(i,2) = Post_RECH.DataAnneal.score.Quantile_Score;
    MSE(i,2) = Post_RECH.DataAnneal.predictive_score.MSE;
    MAE(i,2) = Post_RECH.DataAnneal.predictive_score.MAE;
    Violate(i,2) = Post_RECH.DataAnneal.score.Violate;
end
disp('================== Log Marginal Likelihood ========================')
Better = llh(:,1)<llh(:,2);
LogMarginalLikelihood = table(stock_list',llh(:,1),llh(:,2),Better);
LogMarginalLikelihood.Properties.VariableNames = {'Stock','tGARCH','RECH','RECH better?'};
disp(LogMarginalLikelihood)

disp('================== PPS =============================================')
BetterPPS = PPS(:,2)<PPS(:,1);
PPS_table = table(stock_list',PPS(:,1),PPS(:,2),BetterPPS);
PPS_table.Properties.VariableNames = {'Stock','tGARCH','RECH','RECH better?'};
disp(PPS_table)

disp('================== Quantile Score ===================================')
BetterQS = Qscore(:,2)<Qscore(:,1);
QuantileScore_table = table(stock_list',Qscore(:,1),Qscore(:,2),BetterQS);
QuantileScore_table.Properties.VariableNames = {'Stock','tGARCH','RECH','RECH better?'};
disp(QuantileScore_table)

disp('================== MSE ===============================================')
BetterMSE = MSE(:,2)<MSE(:,1);
MSE_table = table(stock_list',MSE(:,1),MSE(:,2),BetterMSE);
MSE_table.Properties.VariableNames = {'Stock','tGARCH','RECH','RECH better?'};
disp(MSE_table)


%=============== testing ===============================
disp('================== Testing LLH: RECH=GARCH v.s. RECH is better than GARCH ========================')
x = llh(:,2)-llh(:,1); % mean(x)>0 indicates that RECH is better than GARCH
[h,pValue] = ttest(x,0,'Tail','right'); % test mean(x)=0 v.s. mean(x)>0. 
                                      % If h = 1, this indicates the rejection of the null hypothesis at the Alpha (0.05 default) significance level.
h
pValue

disp('================== Testing PPS: RECH=GARCH v.s. RECH is better than GARCH ========================')
x = PPS(:,1)-PPS(:,2); % mean(x)>0 indicates that RECH is better than GARCH
[h,pValue] = ttest(x,0,'Tail','right'); % test mean(x)=0 v.s. mean(x)>0. 
                                      % If h = 1, this indicates the rejection of the null hypothesis at the Alpha (0.05 default) significance level.
h
pValue
disp('================== Testing QS: RECH=GARCH v.s. RECH is better than GARCH ========================')
x = Qscore(:,1)-Qscore(:,2); % mean(x)>0 indicates that RECH is better than GARCH
[h,pValue] = ttest(x,0,'Tail','right'); % test mean(x)=0 v.s. mean(x)>0. 
                                      % If h = 1, this indicates the rejection of the null hypothesis at the Alpha (0.05 default) significance level.
h
pValue

disp('================== Testing MSE: RECH=GARCH v.s. RECH is better than GARCH ========================')
x = MSE(:,1)-MSE(:,2); % mean(x)>0 indicates that RECH is better than GARCH
[h,pValue] = ttest(x,0,'Tail','right'); % test mean(x)=0 v.s. mean(x)>0. 
                                      % If h = 1, this indicates the rejection of the null hypothesis at the Alpha (0.05 default) significance level.
h
pValue



clear all
clc
% ==============================================%
% analyze and compare performance across mid-cap stocks
stock_list = {'AGL','ALL','AMC','APA','BSL','FMG','GMG','QBE','WOW','NCM',... % AU mid-cap
    'SWN','CELH','SMCI','PARA','LECO','EMN','OC','RGA','AAL','REG',...% US mid-cap
    'DRX','HGT','HFG','HMSO','CBG','ASC','MSLH','TSCO','VOD','BARC',...% UK mid-cap
    'PAH3DE','SRT3DE','HNR1DE','IFXDE','BEIDE','ADSDE','EOANDE','HEN3DE','RWEDE','HEIDE',...% Ger mid-cap
    'T8015','T8267','T4307','T2802','T7201','T6502','T8421','T7270','T2503','T6701'}; % Japan mid-cap

llh = zeros(length(stock_list),2);
PPS = zeros(length(stock_list),2);
Qscore = zeros(length(stock_list),2);
MSE = zeros(length(stock_list),2);
MAE = zeros(length(stock_list),2);
Violate = zeros(length(stock_list),2);

for ii = 1:length(stock_list)
    stock_name = stock_list{ii};

    tGARCH_str = 'Results_tGARCH_SMC_';
    tGARCH_str = append(tGARCH_str,stock_name);
    load(tGARCH_str)
    llh(ii,1) = Post_tGARCH.LikAnneal.log_llh;
    PPS(ii,1) = Post_tGARCH.DataAnneal.score.PPS;
    Qscore(ii,1) = Post_tGARCH.DataAnneal.score.Quantile_Score;      
    MSE(ii,1) = Post_tGARCH.DataAnneal.predictive_score.MSE;
    MAE(ii,1) = Post_tGARCH.DataAnneal.predictive_score.MAE;
    Violate(ii,1) = Post_tGARCH.DataAnneal.score.Violate;
        
    RECH_str = 'Results_RECH_SMC_';
    RECH_str = append(RECH_str,stock_name);
    load(RECH_str)
    llh(ii,2) = Post_RECH.LikAnneal.log_llh;
    PPS(ii,2) = Post_RECH.DataAnneal.score.PPS;
    Qscore(ii,2) = Post_RECH.DataAnneal.score.Quantile_Score;
    MSE(ii,2) = Post_RECH.DataAnneal.predictive_score.MSE;
    MAE(ii,2) = Post_RECH.DataAnneal.predictive_score.MAE;
    Violate(ii,2) = Post_RECH.DataAnneal.score.Violate;
end
disp('================== Log Marginal Likelihood ========================')
BetterLLH = llh(:,1)<llh(:,2);
LogMarginalLikelihood = table(stock_list',llh(:,1),llh(:,2),BetterLLH);
LogMarginalLikelihood.Properties.VariableNames = {'Stock','tGARCH','RECH','RECH better?'};
disp(LogMarginalLikelihood)

disp('================== PPS ========================')
BetterPPS = PPS(:,2)<PPS(:,1);
PPS_table = table(stock_list',PPS(:,1),PPS(:,2),BetterPPS);
PPS_table.Properties.VariableNames = {'Stock','tGARCH','RECH','RECH better?'};
disp(PPS_table)

disp('================== Quantile Score ========================')
BetterQS = Qscore(:,2)<Qscore(:,1);
QuantileScore_table = table(stock_list',Qscore(:,1),Qscore(:,2),BetterQS);
QuantileScore_table.Properties.VariableNames = {'Stock','tGARCH','RECH','RECH better?'};
disp(QuantileScore_table)


%=============== testing ===============================
disp('================== Testing LLH: RECH=GARCH v.s. RECH is better than GARCH ========================')
x = llh(:,2)-llh(:,1); % mean(x)>0 indicates that RECH is better than GARCH
[h,pValue] = ttest(x,0,'Tail','right'); % test mean(x)=0 v.s. mean(x)>0. 
                                      % If h = 1, this indicates the rejection of the null hypothesis at the Alpha (0.05 default) significance level.
h
pValue

disp('================== Testing PPS: RECH=GARCH v.s. RECH is better than GARCH ========================')
x = PPS(:,1)-PPS(:,2); % mean(x)>0 indicates that RECH is better than GARCH
[h,pValue] = ttest(x,0,'Tail','right'); % test mean(x)=0 v.s. mean(x)>0. 
                                      % If h = 1, this indicates the rejection of the null hypothesis at the Alpha (0.05 default) significance level.
h
pValue
disp('================== Testing QS: RECH=GARCH v.s. RECH is better than GARCH ========================')
x = Qscore(:,1)-Qscore(:,2); % mean(x)>0 indicates that RECH is better than GARCH
[h,pValue] = ttest(x,0,'Tail','right'); % test mean(x)=0 v.s. mean(x)>0. 
                                      % If h = 1, this indicates the rejection of the null hypothesis at the Alpha (0.05 default) significance level.
h
pValue

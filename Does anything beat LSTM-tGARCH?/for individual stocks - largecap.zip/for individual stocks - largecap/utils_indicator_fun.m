function f = utils_indicator_fun(y,quantile)
if y<=quantile
    f = 1;
else
    f = 0;
end

end

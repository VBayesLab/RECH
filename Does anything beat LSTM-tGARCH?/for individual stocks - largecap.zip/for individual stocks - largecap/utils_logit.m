function out = utils_logit(in)

out = log(in./(1-in));
end


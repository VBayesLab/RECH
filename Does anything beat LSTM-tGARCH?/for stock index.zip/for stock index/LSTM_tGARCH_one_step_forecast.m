function sigma2_forecast = LSTM_tGARCH_one_step_forecast(y_cur,sigma2_cur,omega_cur,h_cur,C_cur,theta_particles,input_size)
% each particle corresponds to a value of sigma2_forecast

beta0     = theta_particles(:,1);
beta1     = theta_particles(:,2);
psi1      = theta_particles(:,3);
psi2      = theta_particles(:,4);
nu        = theta_particles(:,5);
w_f       = theta_particles(:,6);
b_f       = theta_particles(:,7);
v_f       = theta_particles(:,8:7+input_size);
w_i       = theta_particles(:,8+input_size);
b_i       = theta_particles(:,9+input_size);
v_i       = theta_particles(:,10+input_size:9+2*input_size);
w_o       = theta_particles(:,10+2*input_size);
b_o       = theta_particles(:,11+2*input_size);
v_o       = theta_particles(:,12+2*input_size:11+3*input_size);
w_d       = theta_particles(:,12+3*input_size);
b_d       = theta_particles(:,13+3*input_size);
v_d       = theta_particles(:,14+3*input_size:end);

input     = [omega_cur,y_cur*ones(length(omega_cur),1),sigma2_cur];  % input to LSTM

g_f       = activation(sum(input.*v_f,2) + w_f.*h_cur + b_f,'Tanh');
g_i       = activation(sum(input.*v_i,2) + w_i.*h_cur + b_i,'Tanh');
g_o       = activation(sum(input.*v_o,2) + w_o.*h_cur + b_o,'Sigmoid');
g_d       = activation(sum(input.*v_d,2) + w_d.*h_cur + b_d,'Tanh');
C_forecast= g_f.*C_cur+g_i.*g_d;    
h_forecast      = g_o.*activation(C_forecast,'Sigmoid');
omega_forecast  = beta0 + beta1.*h_forecast;
sigma2_forecast = omega_forecast + psi1.*(1-psi2).*y_cur^2 + psi1.*psi2.*sigma2_cur;

end


    